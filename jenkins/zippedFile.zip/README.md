# aedibus-challenger

```
curl -X POST -i -F "files.zip=@zippedFile.zip" -F "pom.xml=@pom.xml" eliot:password@127.0.0.1:7070/job/java-jobs/buildWithParameters\?token=abc
```
